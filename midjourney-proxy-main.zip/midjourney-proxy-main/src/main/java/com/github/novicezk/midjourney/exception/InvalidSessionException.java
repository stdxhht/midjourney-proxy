package com.github.novicezk.midjourney.exception;

public class InvalidSessionException extends Exception {
	public InvalidSessionException(String message) {
		super(message);
	}
}