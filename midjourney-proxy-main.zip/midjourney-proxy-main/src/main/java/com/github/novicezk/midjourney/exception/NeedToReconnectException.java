package com.github.novicezk.midjourney.exception;

public class NeedToReconnectException extends Exception {
	public NeedToReconnectException(String message) {
		super(message);
	}
}