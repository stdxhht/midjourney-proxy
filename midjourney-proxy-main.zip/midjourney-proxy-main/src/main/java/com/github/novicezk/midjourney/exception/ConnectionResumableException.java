package com.github.novicezk.midjourney.exception;

public class ConnectionResumableException extends Exception {
	public ConnectionResumableException(String message) {
		super(message);
	}
}